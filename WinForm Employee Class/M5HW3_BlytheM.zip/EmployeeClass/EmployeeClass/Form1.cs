﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeClass
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            CreateEmployees();
        }
        public static void CreateEmployees()
        {
            HRLibrary.Employee employee = new HRLibrary.Employee("Susan Meyers", 47899, "Accounting", "Vice President");
            DisplayEmployee(employee);

            HRLibrary.Employee employee2 = new HRLibrary.Employee("Mark Jones", 39119, "IT", "Programmer");
            DisplayEmployee(employee2);

            HRLibrary.Employee employee3 = new HRLibrary.Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");
            DisplayEmployee(employee3);
        }
        public static void DisplayEmployee(HRLibrary.Employee employee)
        {
            MessageBox.Show("Employee List" + "\n" + "" + "\n" + employee.Name + "\n" + employee.IdNumber.ToString() + "\n" + 
                employee.Department + "\n" + employee.Position);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
