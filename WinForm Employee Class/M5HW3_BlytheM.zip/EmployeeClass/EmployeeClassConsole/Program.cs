﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 11/19/19
* CSC 253
* Michael Blythe
* Employee Class WinForm
*/

namespace EmployeeClassConsole
{
    public class Program
    {
        public static void Main(string[] args)
        {

        
            bool exit = false;

            do
            {
                MainMenu();
                string input = Console.ReadLine();
                if (input == "1")
                {

                    HRLibrary.Employee employee = new HRLibrary.Employee("Susan Meyers", 47899, "Accounting", "Vice President");
                    DisplayEmployee(employee);

                    HRLibrary.Employee employee2 = new HRLibrary.Employee("Mark Jones", 39119, "IT", "Programmer");
                    DisplayEmployee(employee2);

                    HRLibrary.Employee employee3 = new HRLibrary.Employee("Joy Rogers", 81774, "Manufacturing", "Engineer");
                    DisplayEmployee(employee3);
                }
                else if (input == "2")
                {
                    exit = true;
                }
                else
                {
                    Console.WriteLine(" ");
                    Console.WriteLine(" ");
                    Console.WriteLine("Not a valid choice");
                    Console.WriteLine(" ");
                }

            } while (exit == false);

        }
        public static void MainMenu()
        {
            Console.WriteLine(" ");
            Console.WriteLine("HR Employee Records");
            Console.WriteLine("1. View Employees");
            Console.WriteLine("2. Exit ");
            Console.WriteLine(" ");
        }
        public static void DisplayEmployee(HRLibrary.Employee employee)
        {
            Console.WriteLine("");
            Console.WriteLine($"Name: {employee.Name}");
            Console.WriteLine($"IdNumber: {employee.IdNumber}");
            Console.WriteLine($"Department: {employee.Department}");
            Console.WriteLine($"Position: {employee.Position}");
            Console.WriteLine("");
        }
    }
}
