﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 9/15/19
* CSC 253
* Michael Blythe
* Word Counter
*/


namespace word_counter
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            do
            {
                Menu();
                string input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        WordCount();
                        break;
                    case "2":
                        exit = true;
                        break;
                }
            } while (exit == false);

        }
        static void WordCount()
        {
            Console.Write("Enter line here: ");
            string test = Console.ReadLine();
            char[] seperator = { ' ' };
            int count = test.Split(seperator, StringSplitOptions.RemoveEmptyEntries).Length;
            Display(count);
        }
        static void Display(int count)
        {
            Console.WriteLine($"The total number of words: {count}");
            Console.ReadLine();
        }
        public static void Menu()
        {
            Console.WriteLine(" ");
            Console.WriteLine("Word Counter Main Menu");
            Console.WriteLine(" ");
            Console.WriteLine("1. Run Word Counter");
            Console.WriteLine("2. Exit");
            Console.WriteLine(" ");
            Console.Write("Choose an option: ");
        }
    }
}
