﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonClassLibrary
{
    public class CreatePerson
    {
        public static Person GetPersonInfo()
        {
            Person person = new Person();

            Console.WriteLine(" ");
            Console.Write("What is your name? ");
            person.Name = Console.ReadLine();

            Console.Write("What is your age? ");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int output))
            {
                person.Age = output;
            }
            else
            {
                Console.WriteLine("Not a valid number");
                Console.WriteLine("");
                Console.ReadLine();
            }

            Console.Write("What is your gender? ");
            person.Gender = Console.ReadLine();

            Console.Write("What is your Occupation? ");
            person.Occupation = Console.ReadLine();

            Console.WriteLine(" ");
            Console.Write("Class Object Created!");
            return person;
        }
    }
}
