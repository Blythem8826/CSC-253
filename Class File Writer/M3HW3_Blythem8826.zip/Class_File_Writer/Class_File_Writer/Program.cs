﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 9/19/19
* CSC 253
* Michael Blythe
* Class File Writer
*/

namespace Class_File_Writer
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            PersonClassLibrary.Person person = new PersonClassLibrary.Person();

            do
            {
                Menu();
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        person = PersonClassLibrary.CreatePerson.GetPersonInfo();
                        break;
                    case "2":
                        ViewObject(person);
                        break;
                    case "3":
                        FileWriter(person);
                        break;
                    case "4":
                        exit = true;
                        break;
                }

            } while (exit == false);

        }

        public static void ViewObject(PersonClassLibrary.Person person)
        {
            Console.WriteLine($"Name: {person.Name}");
            Console.WriteLine($"Age: {person.Age}");
            Console.WriteLine($"Gender: {person.Gender}");
            Console.WriteLine($"Occupation: {person.Occupation}");
        }
        public static void FileWriter(PersonClassLibrary.Person person)
        {
            try
            {
                StreamWriter outputFile;
                outputFile = File.CreateText("UserInformation.txt");

                Random user = new Random();

                Console.WriteLine("Writing to file..");

                outputFile.WriteLine(person.Name);
                outputFile.WriteLine(person.Age);
                outputFile.WriteLine(person.Gender);
                outputFile.WriteLine(person.Occupation);

                outputFile.Close();

                Console.WriteLine($" ");
                Console.WriteLine($"Finished!");
                Console.WriteLine($" ");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        public static void Menu()
        {
            Console.WriteLine(" ");
            Console.WriteLine("This program will allow you to create and store a person class object.");
            Console.WriteLine(" ");
            Console.WriteLine("1. Create new person object");
            Console.WriteLine("2. View person object");
            Console.WriteLine("3. Write object to file");
            Console.WriteLine("4. Exit");
            Console.WriteLine(" ");
            Console.Write("Choose an option: ");
        }
    }
}
