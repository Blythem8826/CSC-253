﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Population_Database
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cityBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.cityBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.populationDBDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'populationDBDataSet.City' table. You can move, or remove it, as needed.
            this.cityTableAdapter.Fill(this.populationDBDataSet.City);

        }

        private void cityDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void buttonSortAsc_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.OrderByPopAsc(this.populationDBDataSet.City);
        }

        private void buttonSortDesc_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.OrderByPopDesc(this.populationDBDataSet.City);
        }

        private void buttonSortName_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.OrderByCity(this.populationDBDataSet.City);
        }

        private void buttonTotalPop_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.SumPop(this.populationDBDataSet.City);
        }

        private void buttonAvgPop_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.AvgPop(this.populationDBDataSet.City);
        }

        private void buttonMaxPop_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.MaxPop(this.populationDBDataSet.City);
        }

        private void buttonMinPop_Click(object sender, EventArgs e)
        {
            this.cityTableAdapter.MinPop(this.populationDBDataSet.City);
        }
    }
}
