﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 9/19/19
* CSC 253
* Michael Blythe
* Random Number File Reader
*/

namespace Random_Number_File_Reader
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            do
            {
                Menu();
                string input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        FileReader();
                        break;
                    case "2":
                        exit = true;
                        break;
                }
            } while (exit == false);
        }
        public static void FileReader()
        {
            int number = 0;
            int count = 0;
            int total = 0;
            try
            {
                StreamReader inputFile;
                inputFile = File.OpenText("RandomNumbers.txt");
                Console.WriteLine("");
                Console.WriteLine("Reading Random Numbers..");
                Console.WriteLine("");
                while (!inputFile.EndOfStream)
                {
                    number = int.Parse(inputFile.ReadLine());
                    total += number;
                    count++;
                    Console.WriteLine(number);
                }
                Console.WriteLine("--------------------------------");
                Console.WriteLine($"Random numbers in file: {count}");
                Console.WriteLine($"Total of random numbers: {total}");

                inputFile.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        public static void Menu()
        {
            Console.WriteLine(" ");
            Console.WriteLine("Random Number File Reader Menu");
            Console.WriteLine(" ");
            Console.WriteLine("1. Run Program");
            Console.WriteLine("2. Exit");
            Console.WriteLine(" ");
            Console.Write("Choose an option: ");
        }
    }
}

