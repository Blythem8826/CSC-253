﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 9/15/19
* CSC 253
* Michael Blythe
* Most Frequently Used Letter
*/

namespace Most_Frequent_Character
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            do
            {
                Menu();
                string input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        LetterCount();
                        break;
                    case "2":
                        exit = true;
                        break;
                }
            } while (exit == false);
            
            
        }
        public static void LetterCount()
        {
            Console.WriteLine("");
            Console.Write("Please enter line here: ");
            string str = Console.ReadLine();
            if (str == "")
            {
                Console.Write("An error has occurred - No line entered.");
            }
            else
            {
                string str1 = str.ToLower();
                string str3 = str1.Replace(" ", "");
                int count = str3.Length;
                List<int> letterTracker = new List<int>();
                Dictionary<string, int> dict = new Dictionary<string, int>();
                foreach (char c in str3)
                {
                    if (letterTracker.Contains(c))
                    {

                        continue;
                    }
                    else
                    {

                        letterTracker.Add(c);
                        string str2 = str3.Replace($"{c}", "");
                        int count2 = str2.Length;
                        int letterCount = count - count2;
                        dict.Add($"{c}", letterCount);
                    }
                }
                var sortedDict = dict.OrderByDescending(i => i.Value);
                var mostUsedLetter = sortedDict.First();
                Console.WriteLine($"The most frequently used character is '{mostUsedLetter.Key}' which appears {mostUsedLetter.Value} times.");
                Console.ReadLine();
            }
            
        }
        public static void Menu()
        {
            Console.WriteLine(" ");
            Console.WriteLine("Most Frequently Used Letter Menu");
            Console.WriteLine(" ");
            Console.WriteLine("1. Run Program");
            Console.WriteLine("2. Exit");
            Console.WriteLine(" ");
            Console.Write("Choose an option: ");
        }
    }
}
