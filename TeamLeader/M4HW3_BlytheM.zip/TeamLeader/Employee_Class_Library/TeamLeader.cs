﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Class_Library
{
    public class TeamLeader : ProductionWorker
    {

        private double _monthlybonus;
        private int _hoursrequired;
        private int _hoursattended;

        public TeamLeader()
        {
            MonthlyBonus = 2000;
            HoursRequired = 20;
            HoursAttended = 0;
        }

        public TeamLeader(double monthlybonus, int hoursrequired, int hoursattended)
        {
            MonthlyBonus = monthlybonus;
            HoursRequired = hoursrequired;
            HoursAttended = hoursattended;

        }

        public double MonthlyBonus { get { return _monthlybonus; } set { _monthlybonus = value; } }
        public int HoursRequired { get { return _hoursrequired; } set { _hoursrequired = value; } }
        public int HoursAttended { get { return _hoursattended; } set { _hoursattended = value; } }

    }
}
