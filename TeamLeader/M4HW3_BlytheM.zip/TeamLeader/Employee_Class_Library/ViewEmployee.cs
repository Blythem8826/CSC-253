﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Class_Library
{
    public class ViewEmployee
    {
        public static void DisplayObject(Employee_Class_Library.ProductionWorker newProWorker,
            Employee_Class_Library.ShiftSupervisor newSuperVisor, Employee_Class_Library.TeamLeader newTeamLeader, int display)
        {

            switch (display)
            {
                case 1:
                    Console.WriteLine($"Employee Name: {newProWorker.EmployeeName}");
                    Console.WriteLine($"Employee ID: {newProWorker.EmployeeID}");
                    Console.WriteLine($"Shift: {newProWorker.ShiftNumber}");
                    Console.WriteLine($"Hourly pay: ${newProWorker.HourlyPay}");
                    Console.WriteLine();
                    break;
                case 2:
                    Console.WriteLine($"Employee Name: {newSuperVisor.EmployeeName}");
                    Console.WriteLine($"Employee ID: {newSuperVisor.EmployeeID}");
                    Console.WriteLine($"Salary: ${newSuperVisor.Salary}");
                    Console.WriteLine($"Bonus: ${newSuperVisor.Bonus}");
                    Console.WriteLine();
                    break;
                case 3:
                    Console.WriteLine($"Employee Name: {newTeamLeader.EmployeeName}");
                    Console.WriteLine($"Employee ID: {newTeamLeader.EmployeeID}");
                    Console.WriteLine($"Shift: {newTeamLeader.ShiftNumber}");
                    Console.WriteLine($"Hourly pay: ${newTeamLeader.HourlyPay}");
                    Console.WriteLine($"Monthly bonus: ${newTeamLeader.MonthlyBonus}");
                    Console.WriteLine($"Training Hours Required: {newTeamLeader.HoursRequired}");
                    Console.WriteLine($"Training Hours Attended: {newTeamLeader.HoursAttended}");
                    Console.WriteLine();
                    break;
            }
        }
    }
}
