﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Class_Library
{
    public class Employee
    {

        private string _employeename;
        private int _employeeid;

        public Employee()
        {
            EmployeeName = "";
            EmployeeID = 0;
        }

        public Employee(string employeename, int employeeid)
        {
            EmployeeName = employeename;
            EmployeeID = employeeid;
        }

        public string EmployeeName { get { return _employeename; } set { _employeename = value; } }
        public int EmployeeID { get { return _employeeid; } set { _employeeid = value; } }

    }
}
