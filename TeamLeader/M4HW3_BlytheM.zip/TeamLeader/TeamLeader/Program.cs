﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 10/31/19
* CSC 253
* Michael Blythe
* TeamLeader Class
*/

namespace TeamLeader
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu.MainMenu();
        }
    }
}
