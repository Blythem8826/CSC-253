﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamLeader
{
    class Menu
    {
        public static void MainMenu()
        {
            bool exit = false;
            int display = 0;
            Employee_Class_Library.ProductionWorker newProWorker = new Employee_Class_Library.ProductionWorker();
            Employee_Class_Library.ShiftSupervisor newSuperVisor = new Employee_Class_Library.ShiftSupervisor();
            Employee_Class_Library.TeamLeader newTeamLeader = new Employee_Class_Library.TeamLeader();

            
            do
            {
                DisplayMenu();
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        newProWorker = Employee_Class_Library.AddEmployee.NewProductionWorker();
                        display = 1;
                        break;
                    case "2":
                        newSuperVisor = Employee_Class_Library.AddEmployee.NewShiftSupervisor();
                        display = 2;
                        break;
                    case "3":
                        newTeamLeader = Employee_Class_Library.AddEmployee.NewTeamLeader();
                        display = 3;
                        break;
                    case "4":
                        Console.WriteLine();
                        Employee_Class_Library.ViewEmployee.DisplayObject(newProWorker, newSuperVisor, newTeamLeader, display);
                        break;
                    case "5":
                    case "exit":
                        exit = true;
                        break;
                }
            } while (exit == false);
        }
        public static void DisplayMenu()
        {
            // main menu diplay
            Console.WriteLine(" ");
            Console.WriteLine("Employee / ProductionWorker Menu");
            Console.WriteLine(" ");
            Console.WriteLine("1. Add ProductionWorker");
            Console.WriteLine("2. Add ShiftSupervisor");
            Console.WriteLine("3. Add TeamLeader");
            Console.WriteLine("4. View Employee");
            Console.WriteLine("5. Exit");
            Console.WriteLine(" ");
            Console.Write("Choose an option: ");
        }
    }
}
