﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TuitionIncrease;
using Xunit;

namespace TuitionIncrease.Tests
{
    public class CalculatorTests
    {
        [Fact]
        public void CalculateTuitionIncrease_MultiplySimpleValues_Fact()
        {

            // Arrange
            double expected = 6120;

            // Act
            double actual = Tuition_Increase.Program.CalculateTuitionIncrease(6000, .02);

            // Assert
            Assert.Equal(expected, actual);
        }
        [Theory]
        [InlineData(1000, 0.02, 1020)]
        public void CalculateTuitionIncrease_MultiplySimpleValues_Theory(double x, double y, double expected)
        {

            // Arrange

            // Act
            double actual = Tuition_Increase.Program.CalculateTuitionIncrease(x, y);

            // Assert
            Assert.Equal(expected, actual);
        }

        [Theory]
        [InlineData(100, 100, 200)]
        public void CalculateSemesterTotal_AddSimpleValues_Theory(double x, double y, double expected)
        {
            // Arrange

            // Act
            double actual = Tuition_Increase.Program.CalculateSemesterTotal(x, y);

            // Assert
            Assert.Equal(expected, actual);
        }

        [Theory]
        [InlineData(100, 100, 200)]
        public void CalculateFullTotal_AddSimpleValues_Theory(double x, double y, double expected)
        {
            // Arrange

            // Act
            double actual = Tuition_Increase.Program.CalculateFullTotal(x, y);

            // Assert
            Assert.Equal(expected, actual);
        }
    }
}
