﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 11/14/19
* CSC 253
* Michael Blythe
* Tuition Increase Unit Tests
*/

namespace Tuition_Increase
{
    public class Program
    {
        static void Main(string[] args)
        {

            bool exit = false;
            do
            {

                Console.WriteLine("This program will show the increase in tuition over the next five years");
                Console.WriteLine("1. Run program");
                Console.WriteLine("2. Exit");
                Console.Write("Choose an option: ");
                string input = Console.ReadLine();
                if (input == "1")
                {
                    Display();
                }

                else if (input == "2")
                {
                    exit = true;
                }

                else
                {
                    Console.WriteLine("Please choose '1' or '2'");
                    Console.WriteLine("");
                }

                Console.ReadLine();
            } while (exit == false);
        }
        public static double CalculateTuitionIncrease(double tuition, double percent)
        {
            tuition += tuition * percent;
            return tuition;
        }
        public static double CalculateSemesterTotal(double tuition, double total)
        {
            total = tuition + tuition;
            return total;
        }
        public static double CalculateFullTotal(double total, double fullTotal)
        {
            fullTotal += total;
            return fullTotal;
        }
        public static void Display()
        {
            double tuition = 6000;
            double percent = 0.02;
            double total = 0;
            double fullTotal = 0;

            for (int count = 1; count <= 5; count++)
            {
                Console.WriteLine("");
                Console.WriteLine($"Year {count}");
                Console.WriteLine(String.Format("Fall tuition: {0:C}", tuition));
                Console.WriteLine(String.Format("Sring tuition: {0:C}", tuition));
                total = CalculateSemesterTotal(tuition, total);
                Console.WriteLine(String.Format("Total yearly tuition for the year: {0:C}", total));
                tuition = CalculateTuitionIncrease(tuition, percent);
                fullTotal = CalculateFullTotal(total, fullTotal);
                Console.WriteLine("");
            }
            Console.WriteLine(String.Format("Final total expense for 5 eyars: {0:C}", fullTotal));
        }
    }
}
