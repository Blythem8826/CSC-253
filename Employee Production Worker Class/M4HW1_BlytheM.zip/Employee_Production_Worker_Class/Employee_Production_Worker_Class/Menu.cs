﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Production_Worker_Class
{
    class Menu
    {
        public static void MainMenu()
        {
            bool exit = false;
            Employee_Class_Library.ProductionWorker newProWorker = new Employee_Class_Library.ProductionWorker();
            do
            {
                DisplayMenu();
                string input = Console.ReadLine();
                
                switch (input)
                {
                    case "1":
                        newProWorker = Employee_Class_Library.AddProductionWorker.NewProductionWorker();
                        break;
                    case "2":
                        Console.WriteLine();
                        Employee_Class_Library.ViewProductionWorker.DisplayObject(newProWorker);
                        break;
                    case "3":
                    case "exit":
                        exit = true;
                        break;
                }
            } while (exit == false);
        }
        public static void DisplayMenu()
        {
            // main menu diplay
            Console.WriteLine(" ");
            Console.WriteLine("Employee / ProductionWorker Menu");
            Console.WriteLine(" ");
            Console.WriteLine("1. Add ProductionWorker");
            Console.WriteLine("2. View ProductionWorker");
            Console.WriteLine("3. Exit");
            Console.WriteLine(" ");
            Console.Write("Choose an option: ");
        }
    }
}
