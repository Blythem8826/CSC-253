﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
 * 10/28/19
 * CSC 253
 * Michael Blythe
 * Employee and ProductionWorker Classes
 */


namespace Employee_Production_Worker_Class
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu.MainMenu();
        }
    }
}
