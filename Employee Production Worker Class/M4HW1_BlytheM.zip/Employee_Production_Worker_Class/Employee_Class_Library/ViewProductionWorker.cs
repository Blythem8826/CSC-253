﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Class_Library
{
    public class ViewProductionWorker
    {
        public static void DisplayObject(Employee_Class_Library.ProductionWorker newProWorker)
        {
            Console.WriteLine($"Employee Name: {newProWorker.EmployeeName}");
            Console.WriteLine($"Employee ID: {newProWorker.EmployeeID}");
            Console.WriteLine($"Shift: {newProWorker.ShiftNumber}");
            Console.WriteLine($"Hourly pay: {newProWorker.HourlyPay}");
            Console.WriteLine();
        }
    }
}
