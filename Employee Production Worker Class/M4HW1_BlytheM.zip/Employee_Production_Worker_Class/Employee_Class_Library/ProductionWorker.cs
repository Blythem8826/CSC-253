﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Class_Library
{
    public class ProductionWorker:Employee
    {

        private int _shiftnumber;
        private double _hourlypay;

        public ProductionWorker()
        {
            ShiftNumber = 0;
            HourlyPay = 0;
        }

        public ProductionWorker(int shiftnumber, double hourlypay)
        {
            ShiftNumber = shiftnumber;
            HourlyPay = hourlypay;
        }

        public int ShiftNumber { get { return _shiftnumber; } set { _shiftnumber = value; } }
        public double HourlyPay { get { return _hourlypay; } set { _hourlypay = value; } }

    }
}
