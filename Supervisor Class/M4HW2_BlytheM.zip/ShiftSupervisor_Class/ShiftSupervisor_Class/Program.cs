﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 10/28/19
* CSC 253
* Michael Blythe
* ShiftSuperVisor Class
*/

namespace ShiftSupervisor_Class
{
    class Program
    {
        static void Main(string[] args)
        {
            Menu.MainMenu();
        }
    }
}
