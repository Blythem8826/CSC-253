﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShiftSupervisor_Class
{
    class Menu
    {
        public static void MainMenu()
        {
            bool exit = false;
            int display = 0;
            Employee_Class_Library.ProductionWorker newProWorker = new Employee_Class_Library.ProductionWorker();
            Employee_Class_Library.ShiftSupervisor newSuperVisor = new Employee_Class_Library.ShiftSupervisor();
            do
            {
                DisplayMenu();
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        newProWorker = Employee_Class_Library.AddEmployee.NewProductionWorker();
                        display = 1;
                        break;
                    case "2":
                        newSuperVisor = Employee_Class_Library.AddEmployee.NewShiftSupervisor();
                        display = 2;
                        break;
                    case "3":
                        Console.WriteLine();
                        Employee_Class_Library.ViewEmployee.DisplayObject(newProWorker, newSuperVisor, display);
                        break;
                    case "4":
                    case "exit":
                        exit = true;
                        break;
                }
            } while (exit == false);
        }
        public static void DisplayMenu()
        {
            // main menu diplay
            Console.WriteLine(" ");
            Console.WriteLine("Employee / ProductionWorker Menu");
            Console.WriteLine(" ");
            Console.WriteLine("1. Add ProductionWorker");
            Console.WriteLine("2. Add ShiftSupervisor");
            Console.WriteLine("3. View Employee");
            Console.WriteLine("4. Exit");
            Console.WriteLine(" ");
            Console.Write("Choose an option: ");
        }
    }
}
