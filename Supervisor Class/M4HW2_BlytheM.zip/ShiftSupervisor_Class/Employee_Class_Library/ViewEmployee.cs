﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Class_Library
{
    public class ViewEmployee
    {
        public static void DisplayObject(Employee_Class_Library.ProductionWorker newProWorker, 
            Employee_Class_Library.ShiftSupervisor newSuperVisor, int display)
        {
            switch (display)
            {
                case 1:
                    Console.WriteLine($"Employee Name: {newProWorker.EmployeeName}");
                    Console.WriteLine($"Employee ID: {newProWorker.EmployeeID}");
                    Console.WriteLine($"Shift: {newProWorker.ShiftNumber}");
                    Console.WriteLine($"Hourly pay: ${newProWorker.HourlyPay}");
                    Console.WriteLine();
                    break;
                case 2:
                    Console.WriteLine($"Employee Name: {newSuperVisor.EmployeeName}");
                    Console.WriteLine($"Employee ID: {newSuperVisor.EmployeeID}");
                    Console.WriteLine($"Salary: ${newSuperVisor.Salary}");
                    Console.WriteLine($"Bonus: ${newSuperVisor.Bonus}");
                    Console.WriteLine();
                    break;
            }
        }
    }
}
