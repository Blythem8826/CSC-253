﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee_Class_Library
{
    public class AddEmployee
    {
        public static ProductionWorker NewProductionWorker()
        {
            ProductionWorker newProWorker = new ProductionWorker();

            Console.WriteLine(" ");
            Console.Write("Employee name? ");
            newProWorker.EmployeeName = Console.ReadLine();

            Console.Write("Employee ID? ");
            string input = Console.ReadLine();
            newProWorker.EmployeeID = IntParse(input);

            Console.Write("Shift number (1/2)? ");
            input = Console.ReadLine();
            newProWorker.ShiftNumber = IntParse(input);

            Console.Write("Hourly pay rate? ");
            input = Console.ReadLine();
            newProWorker.HourlyPay = DoubleParse(input);

            return newProWorker;
        }
        public static ShiftSupervisor NewShiftSupervisor()
        {
            ShiftSupervisor newSuperVisor = new ShiftSupervisor();

            Console.WriteLine(" ");
            Console.Write("Employee name? ");
            newSuperVisor.EmployeeName = Console.ReadLine();

            Console.Write("Employee ID? ");
            string input = Console.ReadLine();
            newSuperVisor.EmployeeID = IntParse(input);

            Console.Write("Salary? ");
            input = Console.ReadLine();
            newSuperVisor.Salary = DoubleParse(input);

            Console.Write("Bonus? ");
            input = Console.ReadLine();
            newSuperVisor.Bonus = DoubleParse(input);

            return newSuperVisor;
        }
        public static int IntParse(string input)
        {
            if (int.TryParse(input, out int output))
            {
                return output;
            }
            else
            {
                Console.WriteLine("Not a valid number");
                Console.WriteLine("");
                Console.ReadLine();
                output = 0;
                return output;
            }
        }
        public static double DoubleParse(string input)
        {
            if (double.TryParse(input, out double output))
            {
                return output;
            }
            else
            {
                Console.WriteLine("Not a valid number");
                Console.WriteLine("");
                Console.ReadLine();
                output = 0;
                return output;
            }
        }

    }
}
