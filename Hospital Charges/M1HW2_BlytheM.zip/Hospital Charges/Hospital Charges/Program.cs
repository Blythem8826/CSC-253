﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 9/3/19
* CSC 253
* Michael Blythe
* Hospital Charges
*/

namespace Hospital_Charges
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                Console.WriteLine("Hospital Charges");
                Console.WriteLine(" ");
                Console.WriteLine("1. Calculate Charges");
                Console.WriteLine("2. Exit");
                Console.WriteLine(" ");
                Console.Write("Choose an option: ");
                string input = Console.ReadLine();

                if (input == "1")
                {
                    double stayTotal = 0;
                    double miscTotal = 0;
                    double total = 0;

                    Console.Write("Number of days spent in the hospital: ");
                    input = Console.ReadLine();
                    double days = ParseCheck(input);
                    stayTotal = CalcStayCharges(days);

                    Console.Write("Medication Fees: ");
                    input = Console.ReadLine();
                    double medFees = ParseCheck(input);

                    Console.Write("Surgical Fees: ");
                    input = Console.ReadLine();
                    double surgFees = ParseCheck(input);

                    Console.Write("Lab Fees: ");
                    input = Console.ReadLine();
                    double labFees = ParseCheck(input);

                    Console.Write("Physical Rehab Fees: ");
                    input = Console.ReadLine();
                    double rehabFees = ParseCheck(input);

                    miscTotal = CalcMiscCharges(medFees, surgFees, labFees, rehabFees);

                    total = CalcTotalCharges (miscTotal, stayTotal);
                    Console.WriteLine("");

                    if (days == -1 || medFees == -1 || surgFees == -1 || labFees == -1 || rehabFees == -1)
                    {
                        Console.WriteLine("An error occurred, please check input");
                    }
                    else
                    {
                        Console.WriteLine($"The total amount of charges: ${total}");
                        Console.WriteLine();
                    }
                    Console.WriteLine("");
                }
                else if (input == "2")
                {
                    exit = true;
                }
                else
                {
                    Console.WriteLine("Please choose '1' or '2'");
                    Console.WriteLine(" ");
                }
            } while (exit == false);
        }
        public static double ParseCheck(string input)
        {
            double total = 0;

            if (double.TryParse(input, out total))
            {
                return total;
            }

            else
            {
                Console.WriteLine("Not a valid number");
                total = -1;
                return total;
            }
        }
        public static double CalcStayCharges(double days)
        {
            double stayTotal = 0;
            stayTotal = days * 350;
            return stayTotal;
        }
        public static double CalcMiscCharges(double medFees, double surgFees, double labFees, double rehabFees)
        {
            double miscTotal = 0;
            miscTotal = medFees + surgFees + labFees + rehabFees;
            return miscTotal;
        }
        public static double CalcTotalCharges(double miscTotal, double stayTotal)
        {
            double total = 0;
            total = miscTotal + stayTotal;
            return total;
        }

    }
}
