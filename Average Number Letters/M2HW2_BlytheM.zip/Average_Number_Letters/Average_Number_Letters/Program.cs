﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 9/15/19
* CSC 253
* Michael Blythe
* Average Number of Letters
*/

namespace Average_Number_Letters
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            do
            {
                Menu();
                string input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        WordCount();
                        break;
                    case "2":
                        exit = true;
                        break;
                }
            } while (exit == false);
        }
        static void WordCount()
        {
            Console.Write("Enter line here: ");
            string test = Console.ReadLine();
            char[] seperator = { ' ' };
            int count = test.Split(seperator, StringSplitOptions.RemoveEmptyEntries).Length;
            test = test.Replace(" ", "");
            int count2 = test.Length;
            int total = QuickMath(count, count2);
            Display(count, count2, total);
        }
        static int QuickMath(int count, int count2)
        {
            int total = count2 / count;
            return total;
        }
        static void Display(int count, int count2, int total)
        {
            Console.WriteLine($"The total number of words: {count}");
            Console.WriteLine($"The total number of letters: {count2}");
            Console.WriteLine($"The average number of letters in each word: {total}");
            Console.ReadLine();
        }
        public static void Menu()
        {
            Console.WriteLine(" ");
            Console.WriteLine("Average Number of Letters Menu");
            Console.WriteLine(" ");
            Console.WriteLine("1. Run Program");
            Console.WriteLine("2. Exit");
            Console.WriteLine(" ");
            Console.Write("Choose an option: ");
        }
    }
}

