﻿namespace Personal_Database
{


    partial class EmployeeDataSet
    {
    }
}

namespace Personal_Database.EmployeeDataSetTableAdapters 
{
    
    
    public partial class EmployeeTableAdapter 
    {
    }
}
