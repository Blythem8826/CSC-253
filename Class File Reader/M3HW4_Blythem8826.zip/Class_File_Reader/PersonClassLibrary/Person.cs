﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonClassLibrary
{
    public class Person
    {
        private string _name;
        private int _age;
        private string _gender;
        private string _occupation;

        public Person()
        {
            Name = "";
            Age = 0;
            Gender = "";
            Occupation = "";
        }

        public Person(string name, int age, string gender, string occupation)
        {
            Name = name;
            Age = age;
            Gender = gender;
            Occupation = occupation;
        }

        public string Name
        {
            get
            {
                return _name;
            }

            set
            {
                _name = value;
            }
        }

        public int Age
        {
            get
            {
                return _age;
            }

            set
            {
                _age = value;
            }
        }

        public string Gender
        {
            get
            {
                return _gender;
            }

            set
            {
                _gender = value;
            }
        }

        public string Occupation
        {
            get
            {
                return _occupation;
            }

            set
            {
                _occupation = value;
            }
        }
    }
}
