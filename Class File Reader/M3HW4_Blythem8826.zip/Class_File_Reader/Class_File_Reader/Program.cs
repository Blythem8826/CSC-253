﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 9/19/19
* CSC 253
* Michael Blythe
* Class File Reader
*/

namespace Class_File_Reader
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            PersonClassLibrary.Person person = new PersonClassLibrary.Person();

            do
            {
                Menu();
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        person = FileReader();
                        break;
                    case "2":
                        ViewObject(person);
                        break;
                    case "3":
                        exit = true;
                        break;
                }

            } while (exit == false);

        }

        public static void ViewObject(PersonClassLibrary.Person person)
        {
            Console.WriteLine($"Name: {person.Name}");
            Console.WriteLine($"Age: {person.Age}");
            Console.WriteLine($"Gender: {person.Gender}");
            Console.WriteLine($"Occupation: {person.Occupation}");
        }
        public static PersonClassLibrary.Person FileReader()
        {

            PersonClassLibrary.Person person = new PersonClassLibrary.Person();

            try
            {
                StreamReader inputFile;
                inputFile = File.OpenText("UserInformation.txt");
                Console.WriteLine("");
                Console.WriteLine("Reading User Information..");
                Console.WriteLine("");
                while (!inputFile.EndOfStream)
                {
                    person.Name = inputFile.ReadLine();
                    person.Age = int.Parse(inputFile.ReadLine());
                    person.Gender = inputFile.ReadLine();
                    person.Occupation = inputFile.ReadLine();
                    Console.WriteLine();
                }
                Console.WriteLine("--------------------------------");
                Console.WriteLine("File Information Imported!");
                Console.WriteLine(" ");

                inputFile.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return person;

        }
        public static void Menu()
        {
            Console.WriteLine(" ");
            Console.WriteLine("This program will allow you to import and view a person class object.");
            Console.WriteLine(" ");
            Console.WriteLine("1. Import person object from file");
            Console.WriteLine("2. View person object");
            Console.WriteLine("3. Exit");
            Console.WriteLine(" ");
            Console.Write("Choose an option: ");
        }
    }
}
