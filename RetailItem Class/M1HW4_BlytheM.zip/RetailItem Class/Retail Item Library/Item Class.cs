﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Retail_Item_Library
{
    public class Item
    {
        private string _description;
        private double _unitsonhand;
        private double _price;

        public Item()
        {
            Description = "";
            UnitsOnHand = 0;
            Price = 0;
        }

        public Item(string description, double unitsonhand, double price)
        {
            Description = description;
            UnitsOnHand = unitsonhand;
            Price = price;
        }

        public string Description
        {
            get
            {
                return _description;
            }

            set
            {
                _description = value;
            }
        }

        public double UnitsOnHand
        {
            get
            {
                return _unitsonhand;
            }

            set
            {
                _unitsonhand = value;
            }
        }

        public double Price
        {
            get
            {
                return _price;
            }

            set
            {
                _price = value;
            }
        }
    }

}
