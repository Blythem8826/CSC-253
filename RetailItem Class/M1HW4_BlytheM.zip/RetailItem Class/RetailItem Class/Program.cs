﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * 9/3/19
 * CSC 253
 * Michael Blythe
 * Retail item Class
 */

namespace RetailItem_Class
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            Retail_Item_Library.Item item = new Retail_Item_Library.Item();
            List<Retail_Item_Library.Item> items = new List<Retail_Item_Library.Item>();
            items = CreateInventory(items, item);
            do
            {
                Console.WriteLine("");
                Console.WriteLine("Retail Item Menu");
                Console.WriteLine(" ");
                Console.WriteLine("1. Add item");
                Console.WriteLine("2. View items");
                Console.WriteLine("3. Exit");
                Console.WriteLine(" ");
                Console.Write("Choose an option: ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Retail_Item_Library.Item item4 = new Retail_Item_Library.Item();
                        Console.Write("What is the item description? ");
                        item4.Description = Console.ReadLine();
                        Console.Write("How many units are available? ");
                        string input2 = Console.ReadLine();
                        item4.UnitsOnHand = ParseCheck(input2);
                        Console.Write("What is the price of the item? ");
                        input2 = Console.ReadLine();
                        item4.Price = ParseCheck(input2);
                        items.Add(item4);
                        break;
                    case "2":
                        Loop(items, item);
                        break;
                    case "3":
                        exit = true;
                        break;
                }

            } while (exit == false);

        }
        public static double ParseCheck(string input2)
        {
            double input3 = 0;
            if (double.TryParse(input2, out input3))
            {
                return input3;
            }

            else
            {
                input3 = -1;
                return input3;
            }
        }
        public static void Loop(List<Retail_Item_Library.Item> items, Retail_Item_Library.Item item)
        {
            int count = 1;
            foreach (var i in items)
            {
                Console.WriteLine("");
                Console.WriteLine($"Item {count}");
                Console.WriteLine($"Description: {i.Description}");
                Console.WriteLine($"Units On Hand: {i.UnitsOnHand}");
                Console.WriteLine($"Price: ${i.Price}");
                count += 1;
            }
        }
        public static List<Retail_Item_Library.Item> CreateInventory(List<Retail_Item_Library.Item> items, Retail_Item_Library.Item item)
        {
            item.Description = "Jacket";
            item.UnitsOnHand = 12;
            item.Price = 59.95;
            items.Add(item);

            Retail_Item_Library.Item item2 = new Retail_Item_Library.Item();
            item2.Description = "Jeans";
            item2.UnitsOnHand = 40;
            item2.Price = 34.95;
            items.Insert(1,item2);

            Retail_Item_Library.Item item3 = new Retail_Item_Library.Item();
            item3.Description = "Shirt";
            item3.UnitsOnHand = 20;
            item3.Price = 24.95;
            items.Insert(2, item3);

            return items;
        }
    }
}
