﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 11/14/19
* CSC 253
* Michael Blythe
* Retail Price Calculator Unit Tests
*/

namespace Retail_Price_Calculator
{
    public class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            do
            {
                Console.WriteLine("");
                Console.WriteLine("Retail Price Calculator");
                Console.WriteLine(" ");
                Console.WriteLine("1. Add item");
                Console.WriteLine("2. Exit");
                Console.WriteLine(" ");
                Console.Write("Choose an option: ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        double retail = GetInput();
                        DisplayResults(retail);
                        break;
                    case "2":
                    case "exit":
                        exit = true;
                        break;
                }

            } while (exit == false);
        }
        public static double GetInput()
        {
            Console.WriteLine(" ");
            Console.Write("What is the wholesale cost of the item? $");
            string input2 = Console.ReadLine();
            double wholesale = ParseCheck(input2);
            Console.Write("What is the markup percentage? (eg: .10 for 10%) ");
            string input3 = Console.ReadLine();
            double markup = ParseCheck(input3);
            double retail = CalculateRetail(wholesale, markup);
            return retail;
        }
        public static double CalculateRetail(double wholesale, double markup)
        {
            double retail = 0;
            double temp = 0;
            temp = wholesale * markup;
            retail = wholesale + temp;
            return retail;
        }
        public static void DisplayResults(double retail)
        {
            Console.WriteLine("");
            Console.WriteLine($"The ratail price is ${retail}");
            Console.ReadLine();
        }
        public static double ParseCheck(string inputcheck)
        {
            double input3 = 0;
            if (double.TryParse(inputcheck, out input3))
            {
                return input3;
            }

            else
            {
                Console.WriteLine("Not a valid number");
                return input3;
            }
        }
    }
}
