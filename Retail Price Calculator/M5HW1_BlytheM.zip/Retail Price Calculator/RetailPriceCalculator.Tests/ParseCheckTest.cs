﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Retail_Price_Calculator;
using Xunit;

namespace RetailPriceCalculator.Tests
{
    public class ParseCheckTest
    {
        [Fact]
        public void ParseCheck_ShouldConvertToDouble_Fact()
        {
            string newString = "12";

            // Arrange
            double expected = 12;

            // Act
            double actual = Retail_Price_Calculator.Program.ParseCheck(newString);

            // Assert
            Assert.Equal(expected, actual);
        }
        [Theory]
        [InlineData("12", 12)]
        public void ParseCheck_ShouldConvertToDouble_Theory(string x, double expected)
        {
            // Arrange

            // Act
            double actual = Retail_Price_Calculator.Program.ParseCheck(x);

            // Assert
            Assert.Equal(expected, actual);
        }
    }
}
