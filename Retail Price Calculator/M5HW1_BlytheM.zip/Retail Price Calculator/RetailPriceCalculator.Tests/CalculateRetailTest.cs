﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Retail_Price_Calculator;
using Xunit;

namespace RetailPriceCalculator.Tests
{
    public class CalculateRetailTest
    {
        [Fact]
        public void CalculateRetail_SimpleValuesShouldMultiply_Fact()
        {
            // Arrange
            double expected = 12;

            // Act
            double actual = Retail_Price_Calculator.Program.CalculateRetail(10,.2);

            // Assert
            Assert.Equal(expected, actual);
        }
        [Theory]
        [InlineData(10, .2, 12)]
        [InlineData(10, .4, 14)]
        public void CalculateRetail_SimpleValuesShouldMultiply_Theory(double x, double y, double expected)
        {
            // Arrange

            // Act
            double actual = Retail_Price_Calculator.Program.CalculateRetail(x, y);

            // Assert
            Assert.Equal(expected, actual);
        }
    }
}
