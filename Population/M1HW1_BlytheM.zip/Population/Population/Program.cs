﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 8/29/19
* CSC 253
* Michael Blythe
* Population tracker
*/

namespace Population
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;

            do
            {
                Console.WriteLine("Population tracker");
                Console.WriteLine(" ");
                Console.WriteLine("1. Run program");
                Console.WriteLine("2. Exit");
                Console.WriteLine(" ");
                Console.Write("Choose an option: ");
                string input = Console.ReadLine();

                if (input == "1")
                {
                    double total = 0;

                    Console.Write("Number of organisms? ");
                    input = Console.ReadLine();
                    double startCount = ParseCheck(input);

                    Console.Write("Daily increase percent? ");
                    input = Console.ReadLine();
                    double popIncrease = ParseCheck(input);

                    Console.Write("Days to multiple? ");
                    input = Console.ReadLine();
                    double days = ParseCheck(input);

                    total = QuickCalc(startCount, popIncrease, days);
                    

                    if (input == "-1")
                    {
                        Console.WriteLine("Not a valid number");
                    }
                    else
                    {
                        Console.WriteLine($"The total number of organisms are {total}.");
                        Console.WriteLine();
                    }

                }
                else if (input == "2")
                {
                    exit = true;
                }
                else
                {
                    Console.WriteLine("Please choose '1' or '2'");
                    Console.WriteLine(" ");
                }
            } while (exit == false);
        }
        public static double ParseCheck(string input)
        {
            double total = 0;

            if (double.TryParse(input, out total))
            {
                return total;
            }

            else
            {
                total = -1;
                return total;
            }
        }
        public static double QuickCalc(double startCount, double popIncrease, double days)
        {
            double total = 0;
            double increase = startCount * popIncrease;
            total = startCount + increase;

            for (double count = 2; count < days; count++)
            {
                double increase2 = total * popIncrease;
                total = total + increase2;
            }
            return total;
        }



    }
}
