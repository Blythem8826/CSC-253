﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 9/15/19
* CSC 253
* Michael Blythe
* Word Separator
*/

namespace Word_Separator
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            do
            {
                Menu();
                string input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        WordProcessor();
                        break;
                    case "2":
                        exit = true;
                        break;
                }
            } while (exit == false);


        }
        public static void WordProcessor()
        {
            Console.WriteLine("");
            Console.Write("Please enter line here: ");
            string str = Console.ReadLine();
            if (str == "")
            {
                Console.Write("An error has occurred - No line entered.");
            }
            else
            {
                int index = 0;
                string str2 = "";
                string temp = "";
                string temp2 = "";
                foreach (char c in str)
                {
                    var result = char.IsUpper(c);
                    if (result is true)
                    {
                        if (index == 0)
                        {
                            str2 = char.ToString(c);
                            index++;
                            continue;
                        }
                        else
                        {
                            temp = char.ToString(c);
                            temp2 = temp.ToLower();
                            str2 = str2 + " " + temp2;
                        }
                    }
                    else
                    {
                        temp = char.ToString(c);
                        str2 = str2 + temp;
                    }
                }
                Display(str2);
            }

        }
        public static void Display(string str2)
        {
            Console.WriteLine($"New line: {str2}");
            Console.ReadLine();
        }
        public static void Menu()
        {
            Console.WriteLine(" ");
            Console.WriteLine("Word Separator Menu");
            Console.WriteLine(" ");
            Console.WriteLine("1. Run Program");
            Console.WriteLine("2. Exit");
            Console.WriteLine(" ");
            Console.Write("Choose an option: ");
        }
    }
}
