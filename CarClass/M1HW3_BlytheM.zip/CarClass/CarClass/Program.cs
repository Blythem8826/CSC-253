﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CarClass;

/**
* 9-2-19
* CSC-253
* Michael Blythe
* Car Class
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {

            bool exit = false;
            Car car = new Car();
            do
            {

                Console.WriteLine("Car Creator Menu");
                Console.WriteLine("");
                Console.WriteLine("1. Create a car.");
                Console.WriteLine("2. Accelerate. ");
                Console.WriteLine("3. Brake. ");
                Console.WriteLine("4. Exit. ");
                Console.WriteLine("");
                Console.Write("Choose an option: ");
                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Console.Write("What is the year of the car? ");
                        string input2 = Console.ReadLine();
                        car.Year = ParseCheck(input2);
                        Console.Write("What is the make of the car? ");
                        car.Make = Console.ReadLine();
                        Console.WriteLine("");
                        Console.WriteLine("Car Created!");
                        if (car.Year == -1)
                        {
                            car.Make = "";
                            Console.WriteLine("Invalid Year, car object deleted");
                            Console.WriteLine("");
                        }
                        else
                        {
                            Console.WriteLine($"Year:{car.Year}");
                            Console.WriteLine($"Make:{car.Make}");
                        }
                        Console.WriteLine("");
                        break;
                    case "2":
                        if (car.Make != "")
                        {
                            car.Accelerate();
                            Console.WriteLine($"You have accelerated! You are now going {car.Speed} mph.");
                        }
                        else
                        {
                            Console.WriteLine("");
                            Console.WriteLine("Please create a car first!");
                            Console.WriteLine("");
                        }
                        break;
                    case "3":
                        if (car.Make != "")
                        {
                            car.Brake();
                            Console.WriteLine($"You have braked! You are now going {car.Speed} mph.");
                        }
                        else
                        {
                            Console.WriteLine("");
                            Console.WriteLine("Please create a car first!");
                            Console.WriteLine("");
                        }
                        break;
                    case "4":
                        exit = true;
                        break;
                }
                
            } while (exit == false);


        }
        public static int ParseCheck(string input2)
        {
            int input3 = 0;
            if (int.TryParse(input2, out input3))
            {
                return input3;
            }

            else
            {
                Console.WriteLine("Not a valid number, Errors may occur");
                input3 = -1;
                return input3;
            }
        }
    }
}