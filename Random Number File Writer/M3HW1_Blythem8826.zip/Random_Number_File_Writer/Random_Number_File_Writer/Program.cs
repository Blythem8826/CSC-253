﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 9/17/19
* CSC 253
* Michael Blythe
* Random Number File Writer
*/

namespace Random_Number_File_Writer
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            do
            {
                Menu();
                string input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        GetNumber();
                        break;
                    case "2":
                        exit = true;
                        break;
                }
            } while (exit == false);
        }
        public static void GetNumber()
        {
            Console.Write("How many random numbers would you like to write to the file? ");
            string input = Console.ReadLine();
            if (int.TryParse(input, out int userNumber))
            {
                FileWriter(userNumber);
            }
            else
            {
                Console.WriteLine("Not a valid number");
            }
        }
        public static int CreateRandom(Random rand)
        {
            int ranNumber;
            ranNumber = rand.Next(100) + 1;
            return ranNumber;

        }
        public static void FileWriter(int userNumber)
        {
            try
            {
                StreamWriter outputFile;
                outputFile = File.CreateText("RandomNumbers.txt");

                Random rand = new Random();

                for (int count = 1; count <= userNumber; count++)
                {
                    int ranNumber = CreateRandom(rand);
                    Console.WriteLine($"Random number: {ranNumber}");
                    outputFile.WriteLine(ranNumber);
                }
                outputFile.Close();
                Console.WriteLine($" ");
                Console.WriteLine($"Finished!");
                Console.WriteLine($" ");
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        public static void Menu()
        {
            Console.WriteLine(" ");
            Console.WriteLine("Random Number File Writer Menu");
            Console.WriteLine(" ");
            Console.WriteLine("1. Run Program");
            Console.WriteLine("2. Exit");
            Console.WriteLine(" ");
            Console.Write("Choose an option: ");
        }
    }
}
